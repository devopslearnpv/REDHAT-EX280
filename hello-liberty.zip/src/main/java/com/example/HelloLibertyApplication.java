package com.example;

import jakarta.ws.rs.ApplicationPath;
import jakarta.ws.rs.GET;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import jakarta.ws.rs.core.Application;

@ApplicationPath("/api")
public class HelloLibertyApplication extends Application {
}

@Path("/hello")
class HelloResource {
    @GET
    public Response hello() {
        return Response.ok("Hello from Liberty!").build();
    }
}
